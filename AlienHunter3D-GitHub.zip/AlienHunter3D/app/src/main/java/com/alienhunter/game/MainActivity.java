package com.alienhunter.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.Random;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(new Game()); }
    class Game extends View {
        final Paint p=new Paint(3); final Random rng=new Random();
        final ToneGenerator tones=new ToneGenerator(AudioManager.STREAM_MUSIC,65);
        int level=1, score=0, alien=0, tries=0; boolean playing=false; String message="";
        float[] xs=new float[20], ys=new float[20]; int[] colors=new int[20];
        Game(){ super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void next(){playing=true;tries=0;message="Найди инопланетянина!";alien=rng.nextInt(20);
            for(int i=0;i<20;i++){xs[i]=.12f+(i%4)*.25f;ys[i]=.24f+(i/4)*.135f;colors[i]=Color.rgb(70+rng.nextInt(130),85+rng.nextInt(130),110+rng.nextInt(125));} invalidate();}
        void txt(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);}
        void rect(Canvas c,int color,float l,float t,float r,float b){p.setColor(color);c.drawRect(l,t,r,b,p);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int w=getWidth(),h=getHeight();canvas.drawColor(Color.rgb(14,22,46));
            rect(canvas,Color.rgb(22,38,70),0,h*.13f,w,h*.90f);
            for(int i=0;i<9;i++){float x=i*w/8f;rect(canvas,Color.rgb(34,57,89),x,h*.18f,x+w*.065f,h*.78f);}
            rect(canvas,Color.rgb(32,65,64),0,h*.81f,w,h);
            txt(canvas,"ALIEN HUNTER 3D",w/2f,h*.075f,w*.073f,Color.WHITE);
            txt(canvas,"Уровень "+level+"   •   Очки "+score,w/2f,h*.118f,w*.046f,Color.rgb(151,234,244));
            if(!playing){txt(canvas,"Найди пришельца среди 20 людей",w/2f,h*.42f,w*.048f,Color.WHITE);
                rect(canvas,Color.rgb(26,156,137),w*.16f,h*.50f,w*.84f,h*.60f);
                txt(canvas,"ИГРАТЬ",w/2f,h*.565f,w*.08f,Color.WHITE);
            }else{
                for(int i=0;i<20;i++){
                    float x=xs[i]*w,y=ys[i]*h; float r=w*.042f;
                    p.setColor(Color.rgb(8,19,32));canvas.drawOval(x-r*1.2f,y+r*2.1f,x+r*1.2f,y+r*2.65f,p);
                    p.setColor(colors[i]);canvas.drawRoundRect(x-r*.8f,y+r*.35f,x+r*.8f,y+r*1.9f,r*.3f,r*.3f,p);
                    p.setStrokeWidth(r*.28f);canvas.drawLine(x-r*.43f,y+r*1.65f,x-r*.50f,y+r*2.3f,p);canvas.drawLine(x+r*.43f,y+r*1.65f,x+r*.50f,y+r*2.3f,p);
                    p.setColor(Color.rgb(242,191,145));canvas.drawCircle(x,y,r*.78f,p);
                    p.setColor(Color.rgb(30,38,45));canvas.drawCircle(x-r*.25f,y-r*.06f,r*.08f,p);canvas.drawCircle(x+r*.25f,y-r*.06f,r*.08f,p);
                }
                txt(canvas,message,w/2f,h*.92f,w*.043f,Color.WHITE);
                txt(canvas,"Нажимай на персонажей",w/2f,h*.965f,w*.036f,Color.rgb(171,208,221));
            }
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX()/getWidth(),y=e.getY()/getHeight();if(!playing){next();return true;}
            int chosen=-1;float best=999;
            for(int i=0;i<20;i++){float dx=(x-xs[i]),dy=(y-ys[i]);float d=dx*dx+dy*dy;if(d<best){best=d;chosen=i;}}
            if(best>.0055f)return true;
            tries++;
            if(chosen==alien){score+=Math.max(10,100-tries*10);level++;message="Верно! Следующий уровень";tones.startTone(ToneGenerator.TONE_PROP_ACK,180);next();}
            else{message="Это человек. Попробуй ещё!";tones.startTone(ToneGenerator.TONE_PROP_NACK,160);invalidate();}
            return true;
        }
    }
}
