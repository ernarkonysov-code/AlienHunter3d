# AlienHunter3D
Android touch game prototype. 20 characters, one hidden alien, levels, score and simple tones. This is a 2D placeholder prototype, not full 3D.

## GitHub Actions
Open Actions > Build Android APK > Run workflow. After the job succeeds, download the `AlienHunter3D-debug-APK` artifact, extract the ZIP and install `app-debug.apk` on Android.

The debug APK is for testing, not for Google Play publication. No monetization or multiplayer yet.
